import 'package:flutter/foundation.dart';

import '/backend/sqlite/init.dart';
import 'queries/read.dart';

import 'package:sqflite/sqflite.dart';
export 'queries/read.dart';
export 'queries/update.dart';

class SQLiteManager {
  SQLiteManager._();

  static SQLiteManager? _instance;
  static SQLiteManager get instance => _instance ??= SQLiteManager._();

  static late Database _database;
  Database get database => _database;

  static Future initialize() async {
    if (kIsWeb) {
      return;
    }
    _database = await initializeDatabaseFromDbFile(
      'plants_d_b',
      'PlantsDB.db',
    );
  }

  /// START READ QUERY CALLS

  Future<List<PlantsRow>> plants({
    int? id,
  }) =>
      performPlants(
        _database,
        id: id,
      );

  Future<List<NamesRow>> names() => performNames(
        _database,
      );

  Future<List<FindCompanionRow>> findCompanion({
    int? companionAID,
  }) =>
      performFindCompanion(
        _database,
        companionAID: companionAID,
      );

  Future<List<FindAntagonistRow>> findAntagonist({
    int? antagonistAID,
  }) =>
      performFindAntagonist(
        _database,
        antagonistAID: antagonistAID,
      );

  Future<List<FindCompanionIDRow>> findCompanionID({
    String? companionName,
  }) =>
      performFindCompanionID(
        _database,
        companionName: companionName,
      );

  Future<List<PlantsProfileNameRow>> plantsProfileName({
    int? id,
  }) =>
      performPlantsProfileName(
        _database,
        id: id,
      );

  /// END READ QUERY CALLS

  /// START UPDATE QUERY CALLS

  /// END UPDATE QUERY CALLS
}
