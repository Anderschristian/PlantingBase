import '/backend/sqlite/queries/sqlite_row.dart';
import 'package:sqflite/sqflite.dart';

Future<List<T>> _readQuery<T>(
  Database database,
  String query,
  T Function(Map<String, dynamic>) create,
) =>
    database.rawQuery(query).then((r) => r.map((e) => create(e)).toList());

/// BEGIN PLANTS
Future<List<PlantsRow>> performPlants(
  Database database, {
  int? id,
}) {
  const query = '''
SELECT * From Plants
''';
  return _readQuery(database, query, (d) => PlantsRow(d));
}

class PlantsRow extends SqliteRow {
  PlantsRow(super.data);

  int? get id => data['ID'] as int?;
  String? get plantName => data['PlantName'] as String?;
}

/// END PLANTS

/// BEGIN NAMES
Future<List<NamesRow>> performNames(
  Database database,
) {
  const query = '''
SELECT * From Plants
''';
  return _readQuery(database, query, (d) => NamesRow(d));
}

class NamesRow extends SqliteRow {
  NamesRow(super.data);

  String? get plantName => data['PlantName'] as String?;
  int? get id => data['ID'] as int?;
}

/// END NAMES

/// BEGIN FIND COMPANION
Future<List<FindCompanionRow>> performFindCompanion(
  Database database, {
  int? companionAID,
}) {
  final query = '''
SELECT PlantName, CompanionB
FROM Companions 
JOIN Plants 
ON Companions.CompanionB = Plants.ID 
WHERE CompanionA = $companionAID;
''';
  return _readQuery(database, query, (d) => FindCompanionRow(d));
}

class FindCompanionRow extends SqliteRow {
  FindCompanionRow(super.data);

  String get plantName => data['PlantName'] as String;
  int get companionB => data['CompanionB'] as int;
}

/// END FIND COMPANION

/// BEGIN FIND ANTAGONIST
Future<List<FindAntagonistRow>> performFindAntagonist(
  Database database, {
  int? antagonistAID,
}) {
  final query = '''
SELECT PlantName, AntagonistB
FROM Antagonists 
JOIN Plants 
ON Antagonists.AntagonistB = Plants.ID 
WHERE AntagonistA = $antagonistAID;
''';
  return _readQuery(database, query, (d) => FindAntagonistRow(d));
}

class FindAntagonistRow extends SqliteRow {
  FindAntagonistRow(super.data);

  String get plantName => data['PlantName'] as String;
  int get antagonistB => data['AntagonistB'] as int;
}

/// END FIND ANTAGONIST

/// BEGIN FIND COMPANION ID
Future<List<FindCompanionIDRow>> performFindCompanionID(
  Database database, {
  String? companionName,
}) {
  final query = '''
SELECT ID
FROM Plants
WHERE PlantName = $companionName;
''';
  return _readQuery(database, query, (d) => FindCompanionIDRow(d));
}

class FindCompanionIDRow extends SqliteRow {
  FindCompanionIDRow(super.data);

  int get id => data['ID'] as int;
}

/// END FIND COMPANION ID

/// BEGIN PLANTSPROFILENAME
Future<List<PlantsProfileNameRow>> performPlantsProfileName(
  Database database, {
  int? id,
}) {
  final query = '''
SELECT ID
FROM Plants
WHERE ID = $id;
''';
  return _readQuery(database, query, (d) => PlantsProfileNameRow(d));
}

class PlantsProfileNameRow extends SqliteRow {
  PlantsProfileNameRow(super.data);

  int? get id => data['ID'] as int?;
  String? get plantName => data['PlantName'] as String?;
}

/// END PLANTSPROFILENAME
