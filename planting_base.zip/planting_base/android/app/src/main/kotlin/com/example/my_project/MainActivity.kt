package com.mycompany.plantingbase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
